const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

app.post('/survey', (req, res) => {
    console.log(req.body);
    // Save the data to a database or process it here
    res.json({ message: 'Survey submitted successfully!' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:3000`);
});
