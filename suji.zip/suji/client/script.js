document.getElementById('surveyForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Your opinion has been submitted!');
    document.getElementById('surveyForm').reset();
});
